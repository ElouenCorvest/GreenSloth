# Toy model of upper glycolysis
An example of how to use modelbase v.1.2.3.

We replicated here the toy model of upper glycolysis and used it to show the mca class for the Metabolic Control Analysis. This notebook replicates the results of the toy model introduced for an educational purpose in the Systems Biology textbook by Edda Klipp et al., results from p. 87)
